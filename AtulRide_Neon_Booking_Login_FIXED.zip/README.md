# AtulRide

AtulRide uses a Node.js/Express backend with Neon PostgreSQL.

## Database flow

1. Render starts the backend.
2. `init-db.js` creates/updates the Neon tables.
3. `db.js` reads `DATABASE_URL` and connects to Neon using PostgreSQL SSL.
4. Signup inserts a user into `users`.
5. Login verifies the password and returns a signed JWT.
6. The frontend stores the JWT locally and sends it as `Authorization: Bearer ...`.
7. A booking is saved only through the authenticated `/api/bookings/demo` endpoint.
8. The server gets `user_id` from the verified JWT, not from browser input.
9. The booking stores vehicle, customer, rental, pickup/return, amount, payment method and payment status.
10. Profile → My Bookings reads only the logged-in user's records.

## Render environment variables

Required:
- `DATABASE_URL` — Neon PostgreSQL connection string
- `JWT_SECRET` — long random secret for login sessions

Cashfree:
- `CASHFREE_ENV`
- `CASHFREE_CLIENT_ID`
- `CASHFREE_CLIENT_SECRET`
- `PUBLIC_URL`

## Testing

After deployment:
- Open `/api/health` and confirm `"database":"connected"`.
- Create an account from `auth.html`.
- Confirm a row appears in Neon `users`.
- Login and complete a booking.
- Confirm `bookings.user_id` equals the logged-in user's `users.id`.
- Confirm `booking_status`, `payment_status`, amount and booking details are populated.
- Confirm `login_logs` receives a row after successful login.

The current payment page is a demo-payment UI; the booking database write is real.
