// Initialize / upgrade the AtulRide Neon database.
// Run once from backend with: node init-db.js

const pool = require("./db");

async function init() {
    try {
        console.log("Connecting to Neon and preparing tables...");

        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                email VARCHAR(150) UNIQUE NOT NULL,
                phone VARCHAR(20),
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT NOW(),
                last_login_at TIMESTAMP
            );
        `);

        await pool.query(`
            ALTER TABLE users
            ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS login_logs (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                logged_in_at TIMESTAMP DEFAULT NOW()
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS vehicles (
                id SERIAL PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                description TEXT,
                emoji VARCHAR(10),
                price_per_day NUMERIC(10,2) NOT NULL,
                price_per_hour NUMERIC(10,2),
                is_available BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT NOW()
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS bookings (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE SET NULL,
                customer_name VARCHAR(150) NOT NULL,
                customer_phone VARCHAR(20) NOT NULL,
                customer_email VARCHAR(150),
                rental_type VARCHAR(20),
                pickup_date DATE,
                pickup_time TIME,
                return_date DATE,
                return_time TIME,
                rc_number VARCHAR(50),
                amount NUMERIC(10,2) NOT NULL,
                order_id VARCHAR(100) UNIQUE,
                payment_method VARCHAR(40),
                payment_status VARCHAR(20) DEFAULT 'pending',
                booking_status VARCHAR(20) DEFAULT 'confirmed',
                created_at TIMESTAMP DEFAULT NOW()
            );
        `);

        // Upgrade an existing bookings table without deleting existing data.
        const columns = [
            ["rental_type", "VARCHAR(20)"],
            ["pickup_date", "DATE"],
            ["pickup_time", "TIME"],
            ["return_date", "DATE"],
            ["return_time", "TIME"],
            ["rc_number", "VARCHAR(50)"],
            ["payment_method", "VARCHAR(40)"]
        ];

        for (const [name, type] of columns) {
            await pool.query(
                `ALTER TABLE bookings ADD COLUMN IF NOT EXISTS ${name} ${type}`
            );
        }

        console.log("Tables/columns are ready.");

        const { rows } = await pool.query("SELECT COUNT(*) FROM vehicles");
        if (Number(rows[0].count) === 0) {
            await pool.query(`
                INSERT INTO vehicles
                    (name, description, emoji, price_per_day, price_per_hour)
                VALUES
                    ('Maruti Swift', 'Comfortable & fuel efficient car', '🚗', 1200, 150),
                    ('Hyundai Creta', 'Premium SUV for long journeys', '🚙', 2000, 250),
                    ('Royal Enfield', 'Powerful bike for your trip', '🏍️', 900, 100),
                    ('Honda Activa', 'Easy and affordable city ride', '🛵', 500, 60);
            `);
            console.log("Seeded 4 default vehicles.");
        } else {
            console.log("Vehicles already exist; seed skipped.");
        }

        await pool.end();
        console.log("Database initialization/upgrade completed successfully.");
    } catch (err) {
        console.error("Database initialization failed:", err);
        try { await pool.end(); } catch (_) {}
        process.exit(1);
    }
}

init();
