const express = require("express");
const path = require("path");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const pool = require("./db");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..")));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || process.env.SECRET_KEY;

if (!JWT_SECRET) {
    console.warn("WARNING: JWT_SECRET is not configured. Add JWT_SECRET to Render environment variables.");
}

const CASHFREE_URL =
    process.env.CASHFREE_ENV === "production"
        ? "https://api.cashfree.com"
        : "https://sandbox.cashfree.com";

function createToken(user) {
    if (!JWT_SECRET) throw new Error("JWT_SECRET is not configured");
    return jwt.sign(
        { id: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: "7d" }
    );
}

function authRequired(req, res, next) {
    try {
        const header = req.headers.authorization || "";
        const token = header.startsWith("Bearer ")
            ? header.slice(7)
            : null;

        if (!token || !JWT_SECRET) {
            return res.status(401).json({
                success: false,
                message: "Login required"
            });
        }

        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: "Invalid or expired login session"
        });
    }
}

function cleanEmail(email) {
    return String(email || "").trim().toLowerCase();
}

function parseBookingBody(body) {
    return {
        vehicleId: body.vehicleId ? Number(body.vehicleId) : null,
        customerName: String(body.customerName || "").trim(),
        customerPhone: String(body.customerPhone || "").trim(),
        customerEmail: cleanEmail(body.customerEmail),
        rentalType: body.rentalType || null,
        pickupDate: body.pickupDate || null,
        pickupTime: body.pickupTime || null,
        returnDate: body.returnDate || null,
        returnTime: body.returnTime || null,
        rcNumber: String(body.rcNumber || "").trim() || null,
        amount: Number(body.amount),
        paymentMethod: body.paymentMethod || null
    };
}

async function saveBooking({
    userId,
    booking,
    orderId,
    paymentStatus = "pending",
    bookingStatus = "confirmed"
}) {
    const vehicleResult = booking.vehicleId
        ? await pool.query(
            "SELECT id FROM vehicles WHERE id = $1",
            [booking.vehicleId]
        )
        : { rows: [] };

    if (booking.vehicleId && vehicleResult.rows.length === 0) {
        throw new Error("Selected vehicle does not exist");
    }

    const result = await pool.query(
        `INSERT INTO bookings (
            user_id, vehicle_id, customer_name, customer_phone,
            customer_email, rental_type, pickup_date, pickup_time,
            return_date, return_time, rc_number, amount, order_id,
            payment_method, payment_status, booking_status
        )
        VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8,
            $9, $10, $11, $12, $13, $14, $15, $16
        )
        RETURNING *`,
        [
            userId,
            booking.vehicleId || null,
            booking.customerName,
            booking.customerPhone,
            booking.customerEmail || null,
            booking.rentalType,
            booking.pickupDate,
            booking.pickupTime,
            booking.returnDate,
            booking.returnTime,
            booking.rcNumber,
            booking.amount,
            orderId,
            booking.paymentMethod,
            paymentStatus,
            bookingStatus
        ]
    );

    return result.rows[0];
}

// ================= HEALTH =================

app.get("/api/health", async (req, res) => {
    try {
        await pool.query("SELECT 1");
        res.json({
            success: true,
            database: "connected",
            message: "AtulRide Backend + Neon are running"
        });
    } catch (error) {
        console.error("Health database error:", error);
        res.status(503).json({
            success: false,
            database: "disconnected",
            message: "Backend is running but Neon database is not connected"
        });
    }
});

// ================= AUTH =================

app.post("/api/signup", async (req, res) => {
    try {
        const { name, email, phone, password } = req.body;
        const normalizedEmail = cleanEmail(email);

        if (!name || !normalizedEmail || !password) {
            return res.status(400).json({
                success: false,
                message: "Name, email and password are required"
            });
        }

        if (String(password).length < 6) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 6 characters"
            });
        }

        const existing = await pool.query(
            "SELECT id FROM users WHERE email = $1",
            [normalizedEmail]
        );

        if (existing.rows.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Email already registered"
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        const result = await pool.query(
            `INSERT INTO users (name, email, phone, password_hash)
             VALUES ($1, $2, $3, $4)
             RETURNING id, name, email, phone, created_at`,
            [String(name).trim(), normalizedEmail, phone || null, passwordHash]
        );

        const user = result.rows[0];

        res.status(201).json({
            success: true,
            message: "Account created successfully",
            token: createToken(user),
            user
        });
    } catch (error) {
        console.error("Signup error:", error);
        res.status(500).json({
            success: false,
            message: "Could not create account"
        });
    }
});

app.post("/api/login", async (req, res) => {
    try {
        const normalizedEmail = cleanEmail(req.body.email);
        const { password } = req.body;

        if (!normalizedEmail || !password) {
            return res.status(400).json({
                success: false,
                message: "Email and password are required"
            });
        }

        const result = await pool.query(
            "SELECT * FROM users WHERE email = $1",
            [normalizedEmail]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        const user = result.rows[0];
        const match = await bcrypt.compare(password, user.password_hash);

        if (!match) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        await pool.query(
            "UPDATE users SET last_login_at = NOW() WHERE id = $1",
            [user.id]
        );

        await pool.query(
            "INSERT INTO login_logs (user_id) VALUES ($1)",
            [user.id]
        );

        res.json({
            success: true,
            message: "Login successful",
            token: createToken(user),
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                created_at: user.created_at,
                last_login_at: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
});

app.get("/api/me", authRequired, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT id, name, email, phone, created_at
             FROM users WHERE id = $1`,
            [req.user.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        res.json({ success: true, user: result.rows[0] });
    } catch (error) {
        console.error("Me error:", error);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
});

// ================= VEHICLES =================

app.get("/api/vehicles", async (req, res) => {
    try {
        const result = await pool.query(
            "SELECT * FROM vehicles WHERE is_available = TRUE ORDER BY id"
        );
        res.json({ success: true, vehicles: result.rows });
    } catch (error) {
        console.error("Vehicles fetch error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
});

app.post("/api/vehicles", async (req, res) => {
    try {
        const { name, description, emoji, price_per_day, price_per_hour } = req.body;

        if (!name || !price_per_day) {
            return res.status(400).json({
                success: false,
                message: "Name and price_per_day are required"
            });
        }

        const result = await pool.query(
            `INSERT INTO vehicles
                (name, description, emoji, price_per_day, price_per_hour)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING *`,
            [name, description || null, emoji || "🚗", price_per_day, price_per_hour || null]
        );

        res.status(201).json({
            success: true,
            vehicle: result.rows[0]
        });
    } catch (error) {
        console.error("Vehicle create error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
});

// ================= BOOKINGS =================

// Only the logged-in user's bookings are returned.
app.get("/api/bookings", authRequired, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT b.*, v.name AS vehicle_name
             FROM bookings b
             LEFT JOIN vehicles v ON b.vehicle_id = v.id
             WHERE b.user_id = $1
             ORDER BY b.created_at DESC`,
            [req.user.id]
        );

        res.json({
            success: true,
            bookings: result.rows
        });
    } catch (error) {
        console.error("Bookings fetch error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
});

// Demo payment booking. It is still a demo payment, but the booking is
// a real database record linked to the authenticated user.
app.post("/api/bookings/demo", authRequired, async (req, res) => {
    try {
        const booking = parseBookingBody(req.body);

        if (!booking.customerName || !booking.customerPhone || !booking.amount) {
            return res.status(400).json({
                success: false,
                message: "Customer name, phone and amount are required"
            });
        }

        if (!Number.isFinite(booking.amount) || booking.amount <= 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid booking amount"
            });
        }

        // Always take the user ID from the verified JWT, never from the browser.
        const userResult = await pool.query(
            "SELECT id, name, email, phone FROM users WHERE id = $1",
            [req.user.id]
        );

        if (userResult.rows.length === 0) {
            return res.status(401).json({
                success: false,
                message: "User account no longer exists"
            });
        }

        const orderId = "DEMO_" + Date.now() + "_" + Math.floor(Math.random() * 10000);

        const saved = await saveBooking({
            userId: req.user.id,
            booking,
            orderId,
            paymentStatus: "paid",
            bookingStatus: "confirmed"
        });

        console.log(
            `Demo booking saved: booking_id=${saved.id}, user_id=${req.user.id}, order_id=${saved.order_id}`
        );

        res.status(201).json({
            success: true,
            booking: saved,
            paymentMethod: booking.paymentMethod
        });
    } catch (error) {
        console.error("Demo booking save error:", error);
        res.status(500).json({
            success: false,
            message: "Could not save booking"
        });
    }
});

// ================= CASHFREE ORDER =================

app.post("/create-order", authRequired, async (req, res) => {
    try {
        const booking = parseBookingBody(req.body);

        if (!booking.amount || !booking.customerName || !booking.customerPhone) {
            return res.status(400).json({
                success: false,
                message: "Customer name, phone and amount are required"
            });
        }

        const orderId = "AR_" + Date.now();

        const orderData = {
            order_id: orderId,
            order_amount: booking.amount,
            order_currency: "INR",
            customer_details: {
                customer_id: "customer_" + req.user.id,
                customer_name: booking.customerName,
                customer_phone: booking.customerPhone,
                customer_email: booking.customerEmail || "customer@atulride.com"
            },
            order_meta: {
                return_url:
                    `${process.env.PUBLIC_URL || "http://localhost:" + PORT}/success.html?order_id={order_id}`
            },
            order_note: "AtulRide Vehicle Rental Booking"
        };

        const response = await fetch(
            `${CASHFREE_URL}/pg/orders`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-version": "2025-01-01",
                    "x-client-id": process.env.CASHFREE_CLIENT_ID,
                    "x-client-secret": process.env.CASHFREE_CLIENT_SECRET
                },
                body: JSON.stringify(orderData)
            }
        );

        const data = await response.json();

        if (!response.ok) {
            console.error("Cashfree Error:", data);
            return res.status(response.status).json({
                success: false,
                message: "Cashfree order creation failed",
                error: data
            });
        }

        const saved = await saveBooking({
            userId: req.user.id,
            booking,
            orderId,
            paymentStatus: "pending",
            bookingStatus: "confirmed"
        });

        res.json({
            success: true,
            orderId: data.order_id,
            paymentSessionId: data.payment_session_id,
            bookingId: saved.id
        });
    } catch (error) {
        console.error("Create order error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
});

// ================= FRONTEND =================

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "..", "index.html"));
});

app.listen(PORT, () => {
    console.log(`AtulRide backend running on port ${PORT}`);
});
