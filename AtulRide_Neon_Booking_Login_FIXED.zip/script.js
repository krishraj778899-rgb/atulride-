// ==========================================
// ATULRIDE - AUTH + COMPLETE SCRIPT
// ==========================================

const API_BASE = "";

function getAuthToken() {
    return localStorage.getItem("authToken");
}

function getCurrentUser() {
    try {
        return JSON.parse(localStorage.getItem("currentUser")) || null;
    } catch (_) {
        return null;
    }
}

function saveSession(data) {
    if (data && data.token && data.user) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("currentUser", JSON.stringify(data.user));
        localStorage.setItem("customerData", JSON.stringify({
            id: data.user.id,
            name: data.user.name || "",
            mobile: data.user.phone || "",
            email: data.user.email || "",
            memberSince: data.user.created_at
                ? String(data.user.created_at).slice(0, 4)
                : String(new Date().getFullYear())
        }));
    }
}

function clearSession() {
    [
        "authToken",
        "currentUser",
        "customerData"
    ].forEach(key => localStorage.removeItem(key));
}

async function apiFetch(url, options = {}) {
    const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
    };

    const token = getAuthToken();
    if (token) {
        headers.Authorization = `Bearer ${token}`;
    }

    return fetch(`${API_BASE}${url}`, {
        ...options,
        headers
    });
}

function requireLogin() {
    if (!getAuthToken() || !getCurrentUser()) {
        alert("Please login first to continue booking.");
        window.location.href = "auth.html?next=booking.html";
        return false;
    }
    return true;
}


// ==========================================
// VEHICLE BOOKING
// ==========================================

function bookVehicle(vehicleName, price) {
    localStorage.setItem("selectedVehicle", vehicleName);
    localStorage.setItem("vehiclePrice", price);
    window.location.href = "booking.html";
}


// ==========================================
// BOOKING PAGE ELEMENTS
// ==========================================

const vehicleElement = document.getElementById("vehicle");
const rentalType = document.getElementById("rentalType");
const pickup = document.getElementById("pickup");
const pickupTime = document.getElementById("pickupTime");
const returnDate = document.getElementById("return");
const returnTime = document.getElementById("returnTime");
const rcNumber = document.getElementById("rcNumber");
const total = document.getElementById("total");
const daysText = document.getElementById("daysText");
const bookingForm = document.getElementById("bookingForm");


// ==========================================
// CALCULATE RENT
// ==========================================

function calculateRent() {
    if (!vehicleElement || !rentalType || !pickup || !pickupTime ||
        !returnDate || !returnTime || !total || !daysText) return;

    if (vehicleElement.value === "" || rentalType.value === "" ||
        pickup.value === "" || pickupTime.value === "" ||
        returnDate.value === "" || returnTime.value === "") {
        total.innerText = "0";
        daysText.innerText = "Select vehicle, rental type and dates.";
        return;
    }

    const start = new Date(`${pickup.value}T${pickupTime.value}`);
    const end = new Date(`${returnDate.value}T${returnTime.value}`);
    const difference = end.getTime() - start.getTime();

    if (difference <= 0) {
        total.innerText = "0";
        daysText.innerText = "Return date/time must be after pickup.";
        return;
    }

    if (rentalType.value === "hour") {
        const hours = Math.ceil(difference / (1000 * 60 * 60));
        const selectedOption = vehicleElement.options[vehicleElement.selectedIndex];
        const hourlyPrice = Number(selectedOption.dataset.hourly);
        const totalPrice = hours * hourlyPrice;

        total.innerText = totalPrice.toLocaleString("en-IN");
        daysText.innerText =
            `${hours} hour(s) × ₹${hourlyPrice.toLocaleString("en-IN")} per hour`;
        return;
    }

    if (rentalType.value === "day") {
        const totalHours = difference / (1000 * 60 * 60);
        const days = Math.ceil(totalHours / 24);
        const pricePerDay = Number(vehicleElement.value);
        const totalPrice = days * pricePerDay;

        total.innerText = totalPrice.toLocaleString("en-IN");
        daysText.innerText =
            `${days} day(s) × ₹${pricePerDay.toLocaleString("en-IN")} per day`;
    }
}


// ==========================================
// LOAD SELECTED VEHICLE
// ==========================================

if (vehicleElement) {
    const selectedVehicle = localStorage.getItem("selectedVehicle");
    const selectedPrice = localStorage.getItem("vehiclePrice");

    if (selectedVehicle && selectedPrice) {
        for (const option of vehicleElement.options) {
            if (option.textContent.includes(selectedVehicle)) {
                vehicleElement.value = selectedPrice;
                break;
            }
        }
    }

    vehicleElement.addEventListener("change", calculateRent);
}

if (rentalType) rentalType.addEventListener("change", calculateRent);
if (pickup) pickup.addEventListener("change", calculateRent);
if (pickupTime) pickupTime.addEventListener("change", calculateRent);
if (returnDate) returnDate.addEventListener("change", calculateRent);
if (returnTime) returnTime.addEventListener("change", calculateRent);


// ==========================================
// CONFIRM BOOKING
// ==========================================

if (bookingForm) {
    bookingForm.addEventListener("submit", function(event) {
        event.preventDefault();

        if (!requireLogin()) return;

        if (!total || total.innerText === "0") {
            alert("Please select valid vehicle, rental type and dates.");
            return;
        }

        const user = getCurrentUser();
        const customerName = document.getElementById("name").value.trim();
        const mobile = document.getElementById("mobile").value.trim();

        const selectedOption =
            vehicleElement.options[vehicleElement.selectedIndex];

        const vehicleName =
            selectedOption.textContent.trim();

        const vehicleId =
            selectedOption.dataset.vehicleId || null;

        const booking = {
            vehicleId: vehicleId ? Number(vehicleId) : null,
            vehicle: vehicleName,
            name: customerName,
            mobile,
            email: user.email || "",
            rentalType: rentalType.value,
            pickupDate: pickup.value,
            pickupTime: pickupTime.value,
            returnDate: returnDate.value,
            returnTime: returnTime.value,
            rcNumber: rcNumber ? rcNumber.value.trim() : "",
            totalRent: Number(total.innerText.replace(/,/g, ""))
        };

        // Keep UI state locally for the summary/success page.
        localStorage.setItem("customerName", customerName);
        localStorage.setItem("mobile", mobile);
        localStorage.setItem("bookingData", JSON.stringify(booking));
        localStorage.setItem("bookingTotal", String(booking.totalRent));
        localStorage.setItem("bookingVehicle", vehicleName);
        localStorage.setItem("vehicleId", String(vehicleId || ""));
        localStorage.setItem("rentalType", booking.rentalType);
        localStorage.setItem("pickupDate", booking.pickupDate);
        localStorage.setItem("pickupTime", booking.pickupTime);
        localStorage.setItem("returnDate", booking.returnDate);
        localStorage.setItem("returnTime", booking.returnTime);
        localStorage.setItem("rcNumber", booking.rcNumber);

        window.location.href = "payment.html";
    });
}


// ==========================================
// PAYMENT PAGE SUMMARY
// ==========================================

const paymentAmount = document.getElementById("paymentAmount");
const summaryAmount = document.getElementById("summaryAmount");
const summaryVehicle = document.getElementById("summaryVehicle");
const summaryPickup = document.getElementById("summaryPickup");
const summaryReturn = document.getElementById("summaryReturn");

if (paymentAmount) {
    paymentAmount.innerText = localStorage.getItem("bookingTotal") || "0";
}
if (summaryAmount) {
    summaryAmount.innerText = localStorage.getItem("bookingTotal") || "0";
}
if (summaryVehicle) {
    summaryVehicle.innerText =
        localStorage.getItem("bookingVehicle") || "Not Selected";
}
if (summaryPickup) {
    summaryPickup.innerText = localStorage.getItem("pickupDate") || "-";
}
if (summaryReturn) {
    summaryReturn.innerText = localStorage.getItem("returnDate") || "-";
}


// ==========================================
// SUCCESS PAGE
// ==========================================

const successVehicle = document.getElementById("successVehicle");
const successPickup = document.getElementById("successPickup");
const successReturn = document.getElementById("successReturn");
const successPayment = document.getElementById("successPayment");
const successAmount = document.getElementById("successAmount");
const successRC = document.getElementById("successRC");

if (successVehicle) {
    successVehicle.innerText =
        localStorage.getItem("bookingVehicle") || "-";
}
if (successPickup) {
    successPickup.innerText =
        (localStorage.getItem("pickupDate") || "-") + " " +
        (localStorage.getItem("pickupTime") || "");
}
if (successReturn) {
    successReturn.innerText =
        (localStorage.getItem("returnDate") || "-") + " " +
        (localStorage.getItem("returnTime") || "");
}
if (successPayment) {
    successPayment.innerText =
        localStorage.getItem("paymentMethod") || "-";
}
if (successAmount) {
    successAmount.innerText =
        localStorage.getItem("bookingTotal") || "0";
}
if (successRC) {
    successRC.innerText =
        localStorage.getItem("rcNumber") || "-";
}
